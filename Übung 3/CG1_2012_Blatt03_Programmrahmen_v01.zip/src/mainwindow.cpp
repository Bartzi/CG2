#include "MainWindow.h"

//
// Qt
//
#include <QtGui/QListWidget>
#include <QtGui/QStackedWidget>
#include <QtGui/QHBoxLayout>

using namespace Qt;

MainWindow::MainWindow(QWidget *parent, Qt::WFlags flags) :
	QMainWindow(parent, flags)
{
    // Set window title
    setWindowTitle("3D Computergrafik I - SS2012 - Aufgabenblatt 3");

    // Create main container
    QWidget *container = new QWidget();
    setCentralWidget(container);

    // Add list (on the left)
    QListWidget *list = new QListWidget(container);
    list->addItem("Aufgabe 10");
    list->addItem("Aufgabe 11");
    list->addItem("Aufgabe 12");
    list->setMaximumWidth(150);

    // Add stack of exercise windows (on the right)
    QStackedWidget *stack = new QStackedWidget(container);

    // Add exercises
    m_e10 = new Exercise10();
    m_e11 = new Exercise11();
    m_e12 = new Exercise12();

    stack->addWidget(m_e10);
    stack->addWidget(m_e11);
    stack->addWidget(m_e12);

    // Create layout
    QHBoxLayout* layout = new QHBoxLayout;
    QVBoxLayout* layout2 = new QVBoxLayout;
    layout->addLayout(layout2);
    layout2->addWidget(list);
    layout->addWidget(stack);

    // Add rotation label
    m_rotationLabel = new QLabel();
    m_rotationLabel->setText("Rotation");
    m_rotationLabel->setAlignment(Qt::AlignHCenter);
    layout->addWidget(m_rotationLabel);

    // Add rotation widget
    m_rotationWidget = new RotationWidget(this);
    connect(m_rotationWidget, SIGNAL(rotationChanged(int, int, int)), this, SLOT(onRotationChanged(int, int, int)));
    connect(m_rotationWidget, SIGNAL(rotationReset()),                this, SLOT(onRotationReset()));
    layout->addWidget(m_rotationWidget);

    // Add space
    layout->addSpacing(25);

    // Add button
    m_animationButton = new QPushButton();
    m_animationButton->setText("Stop Animations");
    connect(m_animationButton, SIGNAL(pressed()), this, SLOT(onToggleAnimation()));
    layout2->addWidget(m_animationButton);

    // set layout
    container->setLayout(layout);

    // Connect selection-event of list to select the current visible window
    connect(list, SIGNAL(currentRowChanged(int)), stack, SLOT(setCurrentIndex(int)));
    connect(list, SIGNAL(currentRowChanged(int)), this, SLOT(onSelectExercise(int)));
}

MainWindow::~MainWindow()
{
    //
}

void MainWindow::onSelectExercise(int index)
{
    // Show rotation widget only for 'Rotating Cow'
    m_rotationWidget->setVisible(index == 2);
    m_rotationLabel ->setVisible(index == 2);

    // Stop animations
    //m_rotatingCow->setAnimation(false);
    //m_movingBox  ->setAnimation(false);
    //m_animationButton->setText("Start");
}

void MainWindow::onRotationChanged(int deltaX, int deltaY, int deltaZ)
{
    // Change rotation
    m_e12->rotate(deltaX, deltaY, deltaZ);
}

void MainWindow::onRotationReset()
{
    // Reset rotation
    m_e12->resetRotation();
}

void MainWindow::onToggleAnimation()
{
    m_e10->setAnimation(!m_e10->getAnimation());
    m_e11->setAnimation(!m_e11->getAnimation());
    m_e12->setAnimation(!m_e12->getAnimation());

    if (!m_e10->getAnimation()) m_animationButton->setText("Start Animations");
    else                        m_animationButton->setText("Stop Animations");
}