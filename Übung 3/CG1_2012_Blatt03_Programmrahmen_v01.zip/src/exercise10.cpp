// ======================================
// 3D Computergrafik
// moodle.hpi3d.de
// ======================================
// 
// Sommersemester 2012 - Aufgabenblatt 3
//                     - �bung 10
//
// Diese Datei bearbeiten.
//
// Bearbeiter
// Matr.-Nr: xxxxx
// Matr.-Nr: xxxxx
//
// ======================================

#include "Exercise10.h"

//
// STL
//
#include <math.h>

namespace exercise10 {
    static int g_frame = 0;
    static const float g_light0[] = { 50.0f, 50.0f, 50.0f, 1.0f };

    void solidCube( GLfloat size ) {
        static GLfloat n[6][3] =
        {
            {-1.0, 0.0, 0.0},
            {0.0, 1.0, 0.0},
            {1.0, 0.0, 0.0},
            {0.0, -1.0, 0.0},
            {0.0, 0.0, 1.0},
            {0.0, 0.0, -1.0}
        };
        static GLint faces[6][4] =
        {
            {0, 1, 2, 3},
            {3, 2, 6, 7},
            {7, 6, 5, 4},
            {4, 5, 1, 0},
            {5, 6, 2, 1},
            {7, 4, 0, 3}
        };

        GLfloat v[8][3];
        GLint i;

        v[0][0] = v[1][0] = v[2][0] = v[3][0] = -size / 2;
        v[4][0] = v[5][0] = v[6][0] = v[7][0] = size / 2;
        v[0][1] = v[1][1] = v[4][1] = v[5][1] = -size / 2;
        v[2][1] = v[3][1] = v[6][1] = v[7][1] = size / 2;
        v[0][2] = v[3][2] = v[4][2] = v[7][2] = -size / 2;
        v[1][2] = v[2][2] = v[5][2] = v[6][2] = size / 2;

        for (i = 5; i >= 0; i--) {
            glBegin(GL_QUADS);
            glNormal3fv(&n[i][0]);
            glVertex3fv(&v[faces[i][0]][0]);
            glVertex3fv(&v[faces[i][1]][0]);
            glVertex3fv(&v[faces[i][2]][0]);
            glVertex3fv(&v[faces[i][3]][0]);
            glEnd();
        }
    }
}

using namespace Qt;
using namespace exercise10;

Exercise10::Exercise10(QWidget *parent) :
    GLView(parent)
{
    m_timer = new QTimer(this);
    connect(m_timer, SIGNAL(timeout(void)), this, SLOT(onTimer(void)));
    m_timer->setSingleShot(false);
    m_timer->start(1000/25); // 25 fps at best
}

Exercise10::~Exercise10()
{
    //
}

void Exercise10::rotateClockwise(int frame)
{
	//
	// In dieser Funktion werden die Transformationen ausgef�hrt, die ben�tigt werden, um einen W�rfel 
	// um die Ecke des anderen W�rfels zu rotieren.
	// TODO BEGIN: Nutzen sie die Funktionen glTranslatef und glRotatef, um diese Transformation in 
	// Abh�ngigkeit des aktuellen Frames zu setzen.
	// Bei Frame 0 befindet sich der rotierende W�rfel oberhalb des anderen W�rfels (+y),
	// bei Frame 180 befindet sich der rotierende W�rfel unterhalb des anderen W�rfels (-y).
	// HINWEIS: In Abh�ngigkeit der Kante, um welche der W�rfel gerade rotiert (bzw. klappt), sind andere
	// Transformationen n�tig.
	//
	
	//if (frame < ...)
	//{
	//}
	//else

	// TODO END
}

void Exercise10::onTimer() {
    if (m_animate) {
        g_frame = (g_frame + 1) % 360;
    }
    updateGLView();
}


void Exercise10::initializeGL() {
    GLView::initializeGL();

    glClearColor(0.5, 0.5, 0.5, 1.0);
    glShadeModel(GL_FLAT);
    glEnable(GL_NORMALIZE);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);

    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_POSITION, g_light0);
}

void Exercise10::resizeGL(int w, int h) {
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60, 1.0*w/h, 1, 1000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0, 1.0, -6.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

    updateGL();
}

void Exercise10::paintGL() {
    float red[] = {1.0f, 0.0f, 0.0f, 1.0f};
    float yellow[] = {1.0f, 1.0f, 0.0f, 1.0f};
    float green[] = {0.0f, 1.0f, 0.0f, 1.0f};
    
    glPushMatrix();

    glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

    //
	// center cube
	//
	glMaterialfv(GL_FRONT, GL_DIFFUSE, red);
    solidCube(1.0);
		
    glPushMatrix();
		
    //
    // rotating cube
    //
    rotateClockwise(g_frame);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, yellow);
    solidCube(1.0);

    glPopMatrix();

    glPopMatrix();
    glFlush();
}

bool Exercise10::getAnimation() const
{
    // Return animation status
    return m_animate;
}

void Exercise10::setAnimation(bool active)
{
    // Check if animation state is changed
    if (m_animate != active) {
        // Set animation state
        m_animate = active;

        // Redraw scene
        updateGLView();
    }
}
