#include "Model.h"
#include "stable.h"

#include <locale.h>
#include <stdio.h>
#include <math.h>

std::string ParseString(char **str, char delim)
{
	char token[256];
	char *end = strchr(*str, delim);
	if (end) {
		int size = end-*str;
		strncpy(token, *str, size); token[size] = '\0';
		*str = end+1;
		return token;
	}
	return "";
}

Model::Model()
{
    //
}

Model::~Model()
{
    //
}

void Model::load(const std::string &filename)
{
	char line[256];
	char *pos;

	// Clear model first
	clear();

    // Use a neutral locale
    setlocale(LC_NUMERIC, "C");

	// Open file
	FILE *f = fopen(filename.c_str(), "r");
	if (f) {
		// Read file line by line
		while (fgets(line, 255, f)) {
			// Remove \r and \n at end of line
			while (strlen(line)>0 && line[strlen(line)-1] == '\r' || line[strlen(line)-1] == '\n') line[strlen(line)-1] = '\0';

			// Start at beginning of the line
			pos = line;
			char *endline = pos + strlen(line);

			// Read command
			std::string cmd = ParseString(&pos, ' ');
			if (cmd == "v") {
				// Parse vertex
				std::string sx = ParseString(&pos, ' ');
				std::string sy = ParseString(&pos, ' ');
				std::string sz = ParseString(&pos, '\0');

				// Add vertex to list
				Vertex vertex;
				vertex.x = atof(sx.c_str());
				vertex.y = atof(sy.c_str());
				vertex.z = atof(sz.c_str());
				m_vertices.push_back(vertex);
			} else if (cmd == "vt") {
				// Parse texture coordinate
				std::string su = ParseString(&pos, ' ');
				std::string sv = ParseString(&pos, '\0');

				// Add texture coordinate to list
				TexCoord texCoord;
				texCoord.u = atof(su.c_str());
				texCoord.v = atof(sv.c_str());
				m_texCoords.push_back(texCoord);
			} else if (cmd == "f") {
				// Parse face (triangle)
				std::string v1 = ParseString(&pos, '/');
				std::string t1 = ParseString(&pos, ' ');
				std::string v2 = ParseString(&pos, '/');
				std::string t2 = ParseString(&pos, ' ');
				std::string v3 = ParseString(&pos, '/');
				std::string t3 = ParseString(&pos, '\0');

				// Add face to list
				Face face;
				face.vertex0   = atoi(v1.c_str());
				face.texCoord0 = atoi(t1.c_str());
				face.vertex1   = atoi(v2.c_str());
				face.texCoord1 = atoi(t2.c_str());
				face.vertex2   = atoi(v3.c_str());
				face.texCoord2 = atoi(t3.c_str());
				m_faces.push_back(face);
			} else {
				// Ignore everything else
			}
		}
	}

	// Initialize normal array
	for (unsigned int i=0; i<m_vertices.size(); i++) {
		// Create empty normal vector
		Normal normal;
		normal.x = 0.0;
		normal.y = 0.0;
		normal.z = 0.0;
		normal.vertices = 0;
		m_normals.push_back(normal);
	}

	// Calculate normals
	for (unsigned int i=0; i<m_faces.size(); i++) {
		// Get face
		Face face = m_faces[i];

		// Get vertices
		Vertex v0 = m_vertices[face.vertex0-1];
		Vertex v1 = m_vertices[face.vertex1-1];
		Vertex v2 = m_vertices[face.vertex2-1];

		// Calculate normal vector of face
		Vertex v01;
		v01.x = v1.x - v0.x;
		v01.y = v1.y - v0.y;
		v01.z = v1.z - v0.z;

		Vertex v02;
		v02.x = v2.x - v0.x;
		v02.y = v2.y - v0.y;
		v02.z = v2.z - v0.z;

		Vertex normal;
		normal.x = v01.y*v02.z - v02.y*v01.z;
		normal.y = v02.x*v01.z - v01.x*v02.z;
		normal.z = v01.x*v02.y - v02.y*v01.x;
		double len = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z*normal.z);
		normal.x /= len;
		normal.y /= len;
		normal.z /= len;

		// Add normal to vertex normal
		Normal &n0 = m_normals[face.vertex0-1];
		n0.x += normal.x; n0.x += normal.y; n0.z += normal.z; n0.vertices++;
		Normal &n1 = m_normals[face.vertex1-1];
		n1.x += normal.x; n1.x += normal.y; n1.z += normal.z; n1.vertices++;
		Normal &n2 = m_normals[face.vertex2-1];
		n2.x += normal.x; n2.x += normal.y; n2.z += normal.z; n2.vertices++;
	}

	// Finalize vertex normals
	for (unsigned int i=0; i<m_normals.size(); i++) {
		Normal &n = m_normals[i];
		if (n.vertices > 0) {
			n.x /= (double)n.vertices;
			n.y /= (double)n.vertices;
			n.z /= (double)n.vertices;
		} else {
			n.x = 1.0; n.y = 0.0; n.z = 0.0;
		}
	}
}

void Model::clear()
{
	// Clear model data
	m_vertices.clear();
	m_texCoords.clear();
	m_faces.clear();
}

void Model::render()
{
	// Render faces
	glBegin(GL_TRIANGLES);
	for (unsigned int i=0; i<m_faces.size(); i++) {
		// Get face
		Face face = m_faces[i];

		// Get vertices
		Vertex v0 = m_vertices[face.vertex0-1];
		Vertex v1 = m_vertices[face.vertex1-1];
		Vertex v2 = m_vertices[face.vertex2-1];

		// Get texture coordinates
		Normal n0 = m_normals[face.vertex0-1];
		Normal n1 = m_normals[face.vertex1-1];
		Normal n2 = m_normals[face.vertex2-1];

		// Get normals
		TexCoord t0 = m_texCoords[face.texCoord0-1];
		TexCoord t1 = m_texCoords[face.texCoord1-1];
		TexCoord t2 = m_texCoords[face.texCoord2-1];

		// Draw triangle
		glNormal3f(n0.x, n0.y, n0.z); glTexCoord2f(t0.u, t0.v); glVertex3f(v0.x, v0.y, v0.z);
		glNormal3f(n1.x, n1.y, n1.z); glTexCoord2f(t1.u, t1.v); glVertex3f(v1.x, v1.y, v1.z);
		glNormal3f(n2.x, n2.y, n2.z); glTexCoord2f(t2.u, t2.v); glVertex3f(v2.x, v2.y, v2.z);
	}
	glEnd();
}
