// ======================================
// 3D Computergrafik
// moodle.hpi3d.de
// ======================================
// 
// Sommersemester 2012 - Aufgabenblatt 3
//                     - �bung 11
//
// Diese Datei bearbeiten.
//
// Bearbeiter
// Matr.-Nr: xxxxx
// Matr.-Nr: xxxxx
//
// ======================================

#include "Exercise11.h"

//
// Qt
//
#include <QtGui/QGraphicsView>
#include <QtGui/QGraphicsPixmapItem>
#include <QtGui/QGraphicsRectItem>

//
// STL
//
#include <math.h>

using namespace Qt;

Exercise11::Exercise11(QWidget *parent) :
    GLView(parent), m_frame(0)
{
    // Create timer
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout(void)), this, SLOT(onTimer(void)));
    timer->setSingleShot(false);
    timer->start(1000/25);

    // Define light source
    m_light[0] = 50.0f;
    m_light[1] = 50.0f;
    m_light[2] = 50.0f;
    m_light[3] =  1.0f;
}

Exercise11::~Exercise11()
{
    // Destroy texture
    if (m_texture != 0) {
		glDeleteTextures(1, &m_texture);
    }

    // Destroy quadric
    if (m_quadric) {
		gluDeleteQuadric(m_quadric);
    }
}

bool Exercise11::getAnimation() const
{
    // Return animation status
    return m_animate;
}

/**
*  @brief
*    Start/Stop animation
*/
void Exercise11::setAnimation(bool active)
{
    // Check if animation state is changed
    if (m_animate != active) {
        // Set animation state
        m_animate = active;

        // Redraw scene
        updateGLView();
    }
}

void Exercise11::onTimer() {
    // Update animation
    if (m_animate) {
        m_frame = (m_frame + 1) % 500;
        updateGLView();
    }
}


void Exercise11::initializeGL() {
    GLView::initializeGL();
    
    // Setup OpenGL states and options
    glClearColor(0.5, 0.5, 0.5, 1.0);           // Clear color: gray
    glShadeModel(GL_SMOOTH);                    // Shading
    glEnable(GL_NORMALIZE);                     // Enable normalizing of normal vectors
    glEnable(GL_DEPTH_TEST);                    // Enable Z-buffer
    glEnable(GL_LIGHTING);                      // Enable lighting
    glEnable(GL_LIGHT0);                        // Enable light #0
    glLightfv(GL_LIGHT0, GL_POSITION, m_light); // Define light #0
    glEnable(GL_TEXTURE_2D);                    // Enable texturing

	  // Create quadric (texture coordinates for our ball)
	  m_quadric = gluNewQuadric();
	  gluQuadricNormals(m_quadric, GLU_SMOOTH);
	  gluQuadricTexture(m_quadric, GL_TRUE);

	  // Load texture
	  m_texture = loadTextureRaw("../texture.raw");
}

void Exercise11::resizeGL(int w, int h) {
    // Check width and height
    if (w > 0 && h > 0) {
        // Setup viewport
        glViewport(0, 0, (GLsizei)w, (GLsizei)h);

        // Setup projection matrix
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(40, 1.0*w/h, 1, 10);

        // Setup model-view matrix
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(1.0, 1.2, 4.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

        updateGLView();
    }
}

void Exercise11::paintGL() {
    // Clear background
    glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

    // Save model-view matrix
    glPushMatrix();

	  // Draw reference boxes
	  glDisable(GL_TEXTURE_2D);
	  static GLfloat mat_diffuse_floor[] = {0.0f, 0.5f, 1.0f, 0.0f};
	  glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse_floor);
	  double normal[] = {0.0, 1.0, 0.0};
  	glNormal3dv(normal);
	  glBegin(GL_QUADS);
        glVertex3d(-0.9, 0.8, -0.2);
        glVertex3d(-2.0, 0.8, -0.2);
        glVertex3d(-2.0, 0.8, 0.2);
        glVertex3d(-0.9, 0.8, 0.2);
    glEnd();
    glBegin(GL_QUADS);
        glVertex3d(0.4, -1.05, -0.4);
        glVertex3d(-0.4, -1.05, -0.4);
        glVertex3d(-0.4, -1.05, 0.4);
        glVertex3d(0.4, -1.05, 0.4);
    glEnd();
	  glBegin(GL_QUADS);
	      glVertex3d(0.9, 0.8, 0.2);
	      glVertex3d(2.0, 0.8, 0.2);
	      glVertex3d(2.0, 0.8, -0.2);
	      glVertex3d(0.9, 0.8, -0.2);
	  glEnd();

    // Set translation for ball
    double t = (double)m_frame;
    double px = 0.004*t - 1.0;
    double py;
    if (t<50)      py = 1.0;
    else if (t<250.0)   py = -0.00005 *(t-50.0)*(t-50.0) + 1.0;
    else if (t<450.0)   py = -0.00005 *(450.0-t)*(450.0-t) + 1.0;
    else                py = 1.0;
	  double pz = 0.0;
	  glTranslated(px, py, pz);

	  // Set transformation matrix for ball
	  Matrix mat = calculateMatrix(m_frame);
	  glMultMatrixd(mat.m);

    // Draw ball
	  static GLfloat mat_diffuse_sphere[] = {1.0f, 1.0f, 1.0f, 0.0f};
	  glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse_sphere);
	  glRotated(135.0, 0.0, 1.0, 0.0);
	  glRotated(90.0,  1.0, 0.0, 0.0);
	  glEnable(GL_TEXTURE_2D);
	  glBindTexture(GL_TEXTURE_2D, m_texture);
    gluSphere(m_quadric, 0.2, 20, 20);

    // Restore model-view matrix
    glPopMatrix();
    glFlush();
}

//[-------------------------------------------------------]
//[ Protected functions                                   ]
//[-------------------------------------------------------]
/*
*  @brief
*    Calculate transformation matrix for current animation step
*/
Exercise11::Matrix Exercise11::calculateMatrix(int frame)
{
    //////////////////////////////////////////////////
    // TODO: Set transformation matrix according to current animation step
    //////////////////////////////////////////////////
    if (frame < 240) {
        // Matrix m(...)
        // return m;
    } else if (frame < 250) {
        // Matrix m(...)
        // return m;
    } else if (frame < 400) {
        // Matrix m(...)
        // return m;
    } else {
        // Matrix m(...)
        // return m;
    }

    // Return identity matrix (default implementation, can be removed)
    Matrix m(1.0, 0.0, 0.0, 0.0,
             0.0, 1.0, 0.0, 0.0,
             0.0, 0.0, 1.0, 0.0,
             0.0, 0.0, 0.0, 1.0);
    return m;
}

/*
*  @brief
*    Load 128x128 raw texture file
*/
GLuint Exercise11::loadTextureRaw(const char* filename)
{
    int width  = 128;
    int height = 128;

	// open texture file
	std::ifstream file;
	file.open(filename, std::ios::in | std::ios::binary | std::ios::ate);
	if (!file.is_open()) return 0;

    // Check file size
	std::ifstream::pos_type size = file.tellg();
    if ((int)size != width*height*3) {
        file.close();
        return 0;
    }

    // Allocate texture buffer
	char* data = new char[size];

    // Read texture
	file.seekg(0, std::ios::beg);
	file.read(data, size);
	file.close();

	// Allocate an OpenGL texture name
	GLuint texture;
	glGenTextures(1, &texture);

	// Select our current texture
	glBindTexture(GL_TEXTURE_2D, texture);

	// Build texture mipmaps
	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, data);

	// Free buffer
	delete[] data;

    // Return texture
	return texture;
}
