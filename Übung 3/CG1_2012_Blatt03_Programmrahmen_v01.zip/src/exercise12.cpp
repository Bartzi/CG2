// ======================================
// 3D Computergrafik
// moodle.hpi3d.de
// ======================================
// 
// Sommersemester 2012 - Aufgabenblatt 3
//                     - �bung 12
//
// Diese Datei bearbeiten.
//
// Bearbeiter
// Matr.-Nr: xxxxx
// Matr.-Nr: xxxxx
//
// ======================================

#include "exercise12.h"

//
// STL
//
#include <math.h>

namespace exercise12 {
    //[-------------------------------------------------------]
    //[ Helper functions                                      ]
    //[-------------------------------------------------------]
    /*
     * Transpose matrix
     */
    void transpose(float m[4][4])
    {
        for (int i = 1; i < 4; ++i) {
            for (int j = 0; j < i; ++j) {
                float tmp = m[i][j];
                m[i][j] = m[j][i];
                m[j][i] = tmp;
            }
        }
    }

    /*
     * Create quaternion
     */
    void toQuaternion(float q[4], float m[4][4])
    {
        double tr,s;
        int i,j,k;
        static int nxt[3] = {1,2,0};

        tr = m[0][0] + m[1][1] + m[2][2];
        if (tr > 0.0) {
            q[3] = 0.5 * sqrt(tr + 1.0);
            s = 0.25 / q[3];
            q[0] = (m[2][1] - m[1][2]) * s;
            q[1] = (m[0][2] - m[2][0]) * s;
            q[2] = (m[1][0] - m[0][1]) * s;
        }
        else {
            i = 0;
            if (m[1][1] > m[0][0]) i = 1;
            if (m[2][2] > m[i][i]) i = 2;
            j = nxt[i];
            k = nxt[j];
            q[i] = 0.5 * sqrt(m[i][i] - m[j][j] - m[k][k] + 1.0);
            s = 0.25f / q[i];
            q[3] = (m[k][j] - m[j][k]) * s;
            q[j] = (m[j][i] + m[i][j]) * s;
            q[k] = (m[k][i] + m[i][k]) * s;
        }
    }

    void toAxisAngle(float *angle, float axis[3], float q[4])
    {
        double d = q[0]*q[0] + q[1]*q[1] + q[2]*q[2];
        *angle = 2.0 * atan2(sqrt(d), (double)q[3]) * 180.0 / M_PI;
        double s = 1.0 / sqrt(d + q[3]*q[3]);
        axis[0] = q[0] * s;
        axis[1] = q[1] * s;
        axis[2] = q[2] * s;
    }

    void drawBox(GLfloat size, GLenum type) {
        static GLfloat n[6][3] =
        {
            {-1.0, 0.0, 0.0},
            {0.0, 1.0, 0.0},
            {1.0, 0.0, 0.0},
            {0.0, -1.0, 0.0},
            {0.0, 0.0, 1.0},
            {0.0, 0.0, -1.0}
        };
        static GLint faces[6][4] =
        {
            {0, 1, 2, 3},
            {3, 2, 6, 7},
            {7, 6, 5, 4},
            {4, 5, 1, 0},
            {5, 6, 2, 1},
            {7, 4, 0, 3}
        };

        GLfloat v[8][3];
        GLint i;

        v[0][0] = v[1][0] = v[2][0] = v[3][0] = -size / 2;
        v[4][0] = v[5][0] = v[6][0] = v[7][0] = size / 2;
        v[0][1] = v[1][1] = v[4][1] = v[5][1] = -size / 2;
        v[2][1] = v[3][1] = v[6][1] = v[7][1] = size / 2;
        v[0][2] = v[3][2] = v[4][2] = v[7][2] = -size / 2;
        v[1][2] = v[2][2] = v[5][2] = v[6][2] = size / 2;

        for (i = 5; i >= 0; i--) {
            glBegin(type);
            glNormal3fv(&n[i][0]);
            glVertex3fv(&v[faces[i][0]][0]);
            glVertex3fv(&v[faces[i][1]][0]);
            glVertex3fv(&v[faces[i][2]][0]);
            glVertex3fv(&v[faces[i][3]][0]);
            glEnd();
        }
    }

    void wireCube(GLdouble size) {
      drawBox(size, GL_LINE_LOOP);
    }

    void solidCube(GLdouble size) {
      drawBox(size, GL_QUADS);
    }

    void solidCone(GLdouble base, GLdouble height, GLint slices, GLint stacks) {
        static GLUquadricObj* quadObj = gluNewQuadric();
        gluQuadricDrawStyle(quadObj, GLU_FILL);

        gluQuadricNormals(quadObj, GLU_SMOOTH);
        /* If we ever changed/used the texture or orientation state
        of quadObj, we'd need to change it to the defaults here
        with gluQuadricTexture and/or gluQuadricOrientation. */
        gluCylinder(quadObj, base, 0.0, height, slices, stacks);
    }
}

using namespace Qt;
using namespace exercise12;

Exercise12::Exercise12(QWidget *parent) :
    GLView(parent), m_animate(true), m_frame(0)
{
    // Load cow model
	m_model.load("../cow.obj");

    // Initialize angles
    for (int i=0; i<3; i++) {
        m_sourceAngle[i] = 0;
        m_destAngle  [i] = 0;
    }

    // Set widget size
    setMinimumSize(QSize(800, 600));

    // Create timer
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout(void)), this, SLOT(onTimer(void)));
    timer->setSingleShot(false);
    timer->start(1000/25);
}

Exercise12::~Exercise12()
{
}

/**
*  @brief
*    Change source rotation
*/
void Exercise12::rotate(int deltaX, int deltaY, int deltaZ)
{
    // Change rotation
    m_sourceAngle[0] += deltaX; if (m_sourceAngle[0] > 360) m_sourceAngle[0] -= 360; if (m_sourceAngle[0] < 0) m_sourceAngle[0] += 360;
    m_sourceAngle[1] += deltaY; if (m_sourceAngle[1] > 360) m_sourceAngle[1] -= 360; if (m_sourceAngle[1] < 0) m_sourceAngle[1] += 360;
    m_sourceAngle[2] += deltaZ; if (m_sourceAngle[2] > 360) m_sourceAngle[2] -= 360; if (m_sourceAngle[2] < 0) m_sourceAngle[2] += 360;

    // Redraw scene
    updateGL();
}

/**
*  @brief
*    Reset source rotation
*/
void Exercise12::resetRotation()
{
    // Reset rotation
    m_sourceAngle[0] = 0;
    m_sourceAngle[1] = 0;
    m_sourceAngle[2] = 0;

    // Redraw scene
    updateGL();
}

/**
*  @brief
*    Get animation status
*/
bool Exercise12::getAnimation() const
{
    // Return animation status
    return m_animate;
}

/**
*  @brief
*    Start/Stop animation
*/
void Exercise12::setAnimation(bool active)
{
    // Check if animation state is changed
    if (m_animate != active) {
        // Set animation state
        m_animate = active;

        // Redraw scene
        updateGL();
    }
}


//[-------------------------------------------------------]
//[ Protected slots                                       ]
//[-------------------------------------------------------]
/**
*  @brief
*    Called when the timer has fired
*/
void Exercise12::onTimer()
{
    // Update animation
    if (m_animate) {
        m_frame = (m_frame + 1) % 100;
        updateGL();
    }
}

void Exercise12::initializeGL() {
    GLView::initializeGL();

    // Setup OpenGL states and options
    glClearColor(0.5, 0.5, 0.5, 1.0);   // Clear color: gray
    glDisable(GL_CULL_FACE);             // Disable culling
    glShadeModel(GL_FLAT);                      // Shading
	glEnable(GL_NORMALIZE);                     // Enable normalizing of normal vectors
	glEnable(GL_DEPTH_TEST);                    // Enable Z-buffer
	glDepthFunc(GL_LEQUAL);						// Set depth function
	glEnable(GL_LIGHTING);                      // Enable lighting
	glEnable(GL_LIGHT0);                        // Enable light #0

	// Define light source
	m_light[0] =  -5.0f;
	m_light[1] =  5.0f;
	m_light[2] =  5.0f;
	m_light[3] =  1.0f;
	glLightfv(GL_LIGHT0, GL_POSITION, m_light); // Define light #0
}

void Exercise12::resizeGL(int w, int h) {
    // Check width and height
    if (w > 0 && h > 0) {
        // Setup viewport
        glViewport(0, 0, (GLsizei)w, (GLsizei)h);

        // Setup projection matrix
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(30, 1.0*w/h, 1, 1000);

        // Setup model-view matrix
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(0.0, 0.0, 35.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    }

    updateGL();
}

void Exercise12::paintGL() {

    // Clear Z-Buffer
    glClear(GL_DEPTH_BUFFER_BIT);

	// Draw background
    drawBackground();

    // Draw objects on the left side
    for (int k = 0; k < 3; ++k) {
        glPushMatrix();
        glTranslatef(-8, 5 * (1 - k), 0);
        glScalef(3, 3, 3);
        glRotatef(m_sourceAngle[0], 1, 0, 0);
        glRotatef(m_sourceAngle[1], 0, 1, 0);
        glRotatef(m_sourceAngle[2], 0, 0, 1);
        //if (!m_animate)
        //    drawCow();
        drawCoordinateFrame();
        glPopMatrix();
    }

    // Draw objects on the right side
    for (int k = 0; k < 3; ++k) {
        glPushMatrix();
        glTranslatef(8, 5 * (1 - k), 0);
        glScalef(3, 3, 3);
        glRotatef(m_destAngle[0], 1, 0, 0);
        glRotatef(m_destAngle[1], 0, 1, 0);
        glRotatef(m_destAngle[2], 0, 0, 1);
        //if (!m_animate)
        //    drawCow();
        drawCoordinateFrame();
        glPopMatrix();
    }

    // Draw animated objects
    if (true) { // m_animate
        // Get animation time
        float t = m_frame / 100.0;

        // Draw 3 objects
        for (int k = 0; k < 3; ++k) {
            // Save current model-view matrix
            glPushMatrix();

            // Animate object position
            glTranslatef((1 - t) * -8 + t * 8, 5 * (1 - k), 0);
            glScalef(3, 3, 3);

            // Interpolate rotation
            if (k == 0) {
                // Euler angles
                computeEulerInterpolation(t);
            } else if (k == 1) {
                // Quaternion
                computeQuaternionInterpolation(t);
            } else if (k == 2) {
                // Matrix interpolation
                computeMatrixElementsInterpolation(t);
            }

            // Draw object
            drawCow();
            drawCoordinateFrame();

            // Restore model-view matrix
            glPopMatrix();
        }
    }
}

/*
*  @brief
*    Compute quaternion interpolation
*/
void Exercise12::computeEulerInterpolation(float t)
{
    //////////////////////////////////////////////////
    // TODO: Interpolate euler angles, set transformation matrix
    //////////////////////////////////////////////////
}

/*
*  @brief
*    Compute quaternion interpolation
*/
void Exercise12::computeQuaternionInterpolation(float t)
{
    //////////////////////////////////////////////////
    // TODO: Interpolate using quaternions, set transformation matrix
    //////////////////////////////////////////////////
}

/*
*  @brief
*    Compute quaternion interpolation
*/
void Exercise12::computeMatrixElementsInterpolation(float t)
{
    //////////////////////////////////////////////////
    // TODO: Interpolate matrix elements, set transformation matrix
    //////////////////////////////////////////////////
}

/*
* Slerp function
*/
void Exercise12::slerp(float c[4], float a[4], float b[4], float t)
{
    //////////////////////////////////////////////////
    // TODO: Implement slerp function
    //////////////////////////////////////////////////
}

/*
 * Draw background
 */
void Exercise12::drawBackground()
{
    glDisable(GL_LIGHTING);

    // Set shading mode
    glShadeModel(GL_SMOOTH);

    // Disable Z-buffer for background
    glDisable(GL_DEPTH_TEST);

    // Load identity matrix (modeview)
    glPushMatrix();
    glLoadIdentity();

    // Setup orthogonal projection
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);

    // Draw background quad
    glBegin(GL_QUADS);
    glColor3f(0.8f, 0.8f, 0.8f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glColor3f(0.65f, 0.65f, 0.65f);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glEnd();

    // Reset projection matrix
    glPopMatrix();

    // Reset modelview matrix
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();

    // Enable Z-buffer
    glEnable(GL_DEPTH_TEST);

    // Set shading mode
    glShadeModel(GL_FLAT);
}

/*
 * Draw box
 */
void Exercise12::drawBox()
{
    // Enable polygon offset
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1, 2);

    // Draw filled cube
    glColor3f(0.75, 0.75, 0.75);
    solidCube(1);

    // Disable polygon offset
    glDisable(GL_POLYGON_OFFSET_FILL);

    // Draw outline
    glColor3f(0.0, 0.0, 0.0);
    wireCube(1);
}

/*
 * Draw coordinate frame
 */
void Exercise12::drawCoordinateFrame()
{
	glDisable(GL_LIGHTING);

    // Draw arrow for X, Y and Z axis...
    for (int i = 0; i < 3; i++) {
        // Draw cube
        glPushMatrix();
        glColor3f((i == 0)? 1 : 0,  (i == 1)? 1 : 0,  (i == 2)? 1 : 0);
        glScalef((i == 0)? 0.75 : 0.025,  (i == 1)? 0.75 : 0.025,  (i == 2)? 0.75 : 0.025);
        glTranslatef((i == 0)? 0.5 : 0,  (i == 1)? 0.5 : 0,  (i == 2)? 0.5 : 0);
        solidCube(1);
        glPopMatrix();

        // Draw cone
        glPushMatrix();
        glTranslatef((i == 0)? 0.75 : 0,  (i == 1)? 0.75 : 0,  (i == 2)? 0.75 : 0);
        if (i < 2)
            glRotatef(90, (i == 1)? -1 : 0,  (i == 0)? 1 : 0, 0);
        solidCone(0.05, 0.25, 6, 1);
        glPopMatrix();
    }

	glEnable(GL_LIGHTING);
}

/*
 * Draw cow
 */
void Exercise12::drawCow()
{
	// Use vertex colors
	glEnable(GL_COLOR_MATERIAL);
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	// Set shading
	glShadeModel(GL_SMOOTH);

	// Draw model
	glPushMatrix();
	glScalef(0.1f, 0.1f, 0.1f);
	m_model.render();
	glPopMatrix();
}
