#ifndef __FRAMEWORK_QT_EXERCISE11_H__
#define __FRAMEWORK_QT_EXERCISE11_H__

#include "util/glview.h"

class Exercise11 : public GLView
{
    Q_OBJECT

	public:

        struct Matrix {
            Matrix(double m00, double m01, double m02, double m03, double m10, double m11, double m12, double m13, double m20, double m21, double m22, double m23, double m30, double m31, double m32, double m33) {
                m[ 0] = m00; m[ 1] = m10; m[ 2] = m20; m[ 3] = m30;
                m[ 4] = m01; m[ 5] = m11; m[ 6] = m21; m[ 7] = m31;
                m[ 8] = m02; m[ 9] = m12; m[10] = m22; m[11] = m32;
                m[12] = m03; m[13] = m13; m[14] = m23; m[15] = m33;
            }
            double m[16];
        };

        Exercise11(QWidget *parent = NULL);
    	~Exercise11();

        virtual void initializeGL();
        virtual void resizeGL(int w, int h);
        virtual void paintGL();

        /**
		*  @brief
		*    Get animation status
		*
		*  @return
		*    'true' if animation is active, else 'false'
		*/
    	bool getAnimation() const;

		/**
		*  @brief
		*    Start/Stop animation
		*
		*  @param active
		*    'true' to activate animation, 'false' to stop it
		*/
    	void setAnimation(bool active);

    protected:
        /*
        *  @brief
        *    Calculate transformation matrix for current animation step
        *
        *  @param frame
        *    Animation state (0..499)
        *
        *  @return
        *    4x4 matrix
        */
        Matrix calculateMatrix(int frame);

        /*
        *  @brief
        *    Load 128x128 raw texture file
        *
        *  @param filename
        *    File name
        *
        *  @return
        *    OpenGL texture ID
        */
        GLuint loadTextureRaw(const char* filename);

        float          m_light[4];   // Light source
        bool           m_animate;    // Animation state
        int            m_frame;      // Frame counter
        GLuint         m_texture;    // Texture ID
	    GLUquadricObj *m_quadric;    // GLU quadric

    private:
        //

    public slots:
        void onTimer();

};


#endif // __FRAMEWORK_QT_EXERCISE11_H__
