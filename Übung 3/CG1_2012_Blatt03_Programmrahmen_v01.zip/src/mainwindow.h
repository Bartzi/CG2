#ifndef __FRAMEWORK_QT_MAINWINDOW_H__
#define __FRAMEWORK_QT_MAINWINDOW_H__

#include "exercise10.h"
#include "exercise11.h"
#include "exercise12.h"
#include "rotationwidget.h"

//
// Qt
//
#include <QtGui/QMainWindow>

class MainWindow : public QMainWindow
{
    Q_OBJECT


    //[-------------------------------------------------------]
    //[ Public functions                                      ]
    //[-------------------------------------------------------]
	public:
		/**
		*  @brief
		*    Constructor
		*
		*  @param parent
		*    Parent widget (can be NULL)
		*  @param flags
		*    QT flags
		*/
    	MainWindow(QWidget *parent = NULL, Qt::WFlags flags = 0);

		/**
		*  @brief
		*    Destructor
		*/
    	~MainWindow();

    //[-------------------------------------------------------]
    //[ Protected slots                                       ]
    //[-------------------------------------------------------]
	protected slots:
         void onSelectExercise(int index);
         void onRotationChanged(int deltaX, int deltaY, int deltaZ);
         void onRotationReset();
         void onToggleAnimation();

    private:
        Exercise10* m_e10;
        Exercise11* m_e11;
        Exercise12* m_e12;

        RotationWidget* m_rotationWidget;
        QLabel* m_rotationLabel;
	    QPushButton* m_animationButton;

};

#endif // __FRAMEWORK_QT_MAINWINDOW_H__
