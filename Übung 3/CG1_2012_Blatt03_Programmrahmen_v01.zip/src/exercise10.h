#ifndef __FRAMEWORK_QT_EXERCISE10_H__
#define __FRAMEWORK_QT_EXERCISE10_H__

#include "util/glview.h"

class Exercise10 : public GLView
{
    Q_OBJECT

	public:
        Exercise10(QWidget *parent = NULL);
    	~Exercise10();

        virtual void initializeGL();
        virtual void resizeGL(int w, int h);
        virtual void paintGL();

        /**
		*  @brief
		*    Get animation status
		*
		*  @return
		*    'true' if animation is active, else 'false'
		*/
    	bool getAnimation() const;

		/**
		*  @brief
		*    Start/Stop animation
		*
		*  @param active
		*    'true' to activate animation, 'false' to stop it
		*/
    	void setAnimation(bool active);

    protected:
        void rotateClockwise(int frame);

    private:
        QTimer* m_timer;
        bool    m_animate; // Animation state

    public slots:
        void onTimer();

};


#endif // __FRAMEWORK_QT_EXERCISE10_H__
