#ifndef __FRAMEWORK_QT_EXERCISE12_H__
#define __FRAMEWORK_QT_EXERCISE12_H__

#include "model.h"
#include "util/glview.h"

class Exercise12 : public GLView
{
    Q_OBJECT

	public:
        Exercise12(QWidget *parent = NULL);
    	~Exercise12();

        virtual void initializeGL();
        virtual void resizeGL(int w, int h);
        virtual void paintGL();

        /**
		*  @brief
		*    Change source rotation
		*
		*  @param deltaX
		*    Rotation around X axis (in degrees)
		*  @param deltaY
		*    Rotation around Y axis (in degrees)
		*  @param deltaZ
		*    Rotation around Z axis (in degrees)
		*/
    	void rotate(int deltaX, int deltaY, int deltaZ);

        /**
		*  @brief
		*    Reset source rotation
		*/
    	void resetRotation();

		/**
		*  @brief
		*    Get animation status
		*
		*  @return
		*    'true' if animation is active, else 'false'
		*/
    	bool getAnimation() const;

		/**
		*  @brief
		*    Start/Stop animation
		*
		*  @param active
		*    'true' to activate animation, 'false' to stop it
		*/
    	void setAnimation(bool active);

    protected:
        /*
        *  @brief
		*    Compute quaternion interpolation
        *
        *  @param t
        *    Animation time (0..1)
		*/
        void computeEulerInterpolation(float t);

		/*
        *  @brief
		*    Compute quaternion interpolation
        *
        *  @param t
        *    Animation time (0..1)
		*/
        void computeQuaternionInterpolation(float t);

		/*
        *  @brief
		*    Compute quaternion interpolation
        *
        *  @param t
        *    Animation time (0..1)
		*/
        void computeMatrixElementsInterpolation(float t);

        /*
        * Slerp function
        */
        void slerp(float c[4], float a[4], float b[4], float t);

        /*
        * Draw background
        */
        void drawBackground();

        /*
        * Draw box
        */
        void drawBox();

        /*
        * Draw coordinate frame
        */
        void drawCoordinateFrame();

		/*
		* Draw cow
		*/
		void drawCow();

    //[-------------------------------------------------------]
    //[ Protected slots                                       ]
    //[-------------------------------------------------------]
    protected slots:
        /**
        *  @brief
        *    Called when the timer has fired
        */
        void onTimer();

    private:
        float m_sourceAngle[3];     // Source angles
        float m_destAngle[3];       // Destination angles
        bool  m_animate;            // Animation state
        int   m_frame;              // Frame counter
		Model m_model;				// Cow model
		float m_light[4];			// Light source
};


#endif // __FRAMEWORK_QT_EXERCISE12_H__
