#include "glview.h"

GLView::GLView(QWidget* parent)
    : ImageView(parent) {

    // set canvas size to a good default value
    m_canvasWidth = 800;
    m_canvasHeight = 600;

    setAcceptDrops(true);
}


GLView::~GLView() {
    //
}

void GLView::initializeGL() {
    glewInit();
	if (!GLEW_VERSION_2_0 ||
		!GLEW_EXT_framebuffer_object ||
		!GLEW_ARB_texture_float ||
		!GLEW_ARB_texture_rectangle ||
		!GLEW_EXT_bgra) {
		QMessageBox::critical(this, "Error", "OpenGL 2.0 Graphics Card with EXT_framebuffer_object, ARB_texture_rectangle, ARB_texture_float and EXT_bgra required");
	}
}

void GLView::resizeGL(int w, int h) {
    updateGL();
}

void GLView::paintGL() {
    assert(glGetError() == GL_NO_ERROR);

    glFlush();
}

void GLView::updateGLView() {
    updateGL();
}