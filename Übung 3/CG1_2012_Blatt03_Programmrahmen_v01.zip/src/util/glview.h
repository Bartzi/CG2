#ifndef __FRAMEWORK_QT_GLVIEW_H__
#define __FRAMEWORK_QT_GLVIEW_H__

#include "imageview.h"

class GLView : public ImageView {
    Q_OBJECT
public:
    GLView(QWidget* parent);
    ~GLView();

    virtual void initializeGL();
    virtual void resizeGL(int w, int h);
    virtual void paintGL();

private:
    int m_canvasWidth;
    int m_canvasHeight;

public slots:
    void updateGLView();

};

#endif // __FRAMEWORK_QT_GLVIEW_H__
