#include "RotationWidget.h"

//
// Qt
//
#include <QtGui/QGridLayout>
#include <QtGui/QPushButton>

using namespace Qt;

RotationWidget::RotationWidget(QWidget *parent, Qt::WFlags flags) :
	QWidget(parent, flags)
{
    // Set layout
    QGridLayout *layout = new QGridLayout;
    setLayout(layout);

    // Add button '-X'
    QPushButton *buttonYMinus = new QPushButton(this);
    buttonYMinus->setText("-X");
    buttonYMinus->setMaximumWidth(50);
    buttonYMinus->setAutoRepeat(true);
    buttonYMinus->setAutoRepeatDelay(0);
    buttonYMinus->setAutoRepeatInterval(100);
    connect(buttonYMinus, SIGNAL(pressed()), this, SLOT(rotateYMinus()));
    layout->addWidget(buttonYMinus, 0, 0);

    // Add button '+X'
    QPushButton *buttonYPlus = new QPushButton(this);
    buttonYPlus->setText("+X");
    buttonYPlus->setMaximumWidth(50);
    buttonYPlus->setAutoRepeat(true);
    buttonYPlus->setAutoRepeatDelay(0);
    buttonYPlus->setAutoRepeatInterval(100);
    connect(buttonYPlus, SIGNAL(pressed()), this, SLOT(rotateYPlus()));
    layout->addWidget(buttonYPlus, 0, 1);

    // Add button '-Y'
    QPushButton *buttonXMinus = new QPushButton(this);
    buttonXMinus->setText("-Y");
    buttonXMinus->setMaximumWidth(50);
    buttonXMinus->setAutoRepeat(true);
    buttonXMinus->setAutoRepeatDelay(0);
    buttonXMinus->setAutoRepeatInterval(100);
    connect(buttonXMinus, SIGNAL(pressed()), this, SLOT(rotateXMinus()));
    layout->addWidget(buttonXMinus, 1, 0);

    // Add button '+Y'
    QPushButton *buttonXPlus = new QPushButton(this);
    buttonXPlus->setText("+Y");
    buttonXPlus->setMaximumWidth(50);
    buttonXPlus->setAutoRepeat(true);
    buttonXPlus->setAutoRepeatDelay(0);
    buttonXPlus->setAutoRepeatInterval(100);
    connect(buttonXPlus, SIGNAL(pressed()), this, SLOT(rotateXPlus()));
    layout->addWidget(buttonXPlus, 1, 1);

    // Add button '-Z'
    QPushButton *buttonZMinus = new QPushButton(this);
    buttonZMinus->setText("-Z");
    buttonZMinus->setMaximumWidth(50);
    buttonZMinus->setAutoRepeat(true);
    buttonZMinus->setAutoRepeatDelay(0);
    buttonZMinus->setAutoRepeatInterval(100);
    connect(buttonZMinus, SIGNAL(pressed()), this, SLOT(rotateZMinus()));
    layout->addWidget(buttonZMinus, 2, 0);

    // Add button '+Z'
    QPushButton *buttonZPlus = new QPushButton(this);
    buttonZPlus->setText("+Z");
    buttonZPlus->setMaximumWidth(50);
    buttonZPlus->setAutoRepeat(true);
    buttonZPlus->setAutoRepeatDelay(0);
    buttonZPlus->setAutoRepeatInterval(100);
    connect(buttonZPlus, SIGNAL(pressed()), this, SLOT(rotateZPlus()));
    layout->addWidget(buttonZPlus, 2, 1);

    // Add buton 'reset'
    QPushButton *buttonReset = new QPushButton(this);
    buttonReset->setText("Reset");
    connect(buttonReset, SIGNAL(pressed()), this, SIGNAL(rotationReset()));
    layout->addWidget(buttonReset, 3, 0, 1, 3);
}

RotationWidget::~RotationWidget()
{
    //
}

void RotationWidget::rotateXMinus()
{
    emit rotationChanged(0, -2, 0);
}

void RotationWidget::rotateXPlus()
{
    emit rotationChanged(0, 2, 0);
}

void RotationWidget::rotateYMinus()
{
    emit rotationChanged(-2, 0, 0);
}

void RotationWidget::rotateYPlus()
{
    emit rotationChanged(2, 0, 0);
}

void RotationWidget::rotateZMinus()
{
    emit rotationChanged(0, 0, -2);
}

void RotationWidget::rotateZPlus()
{
    emit rotationChanged(0, 0, 2);
}
