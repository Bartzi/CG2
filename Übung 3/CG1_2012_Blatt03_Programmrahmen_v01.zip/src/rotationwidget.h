#ifndef __FRAMEWORK_OPENGL_ROTATIONWIDGET_H__
#define __FRAMEWORK_OPENGL_ROTATIONWIDGET_H__

//
// Qt
//
#include <QtGui/QWidget>

class RotationWidget : public QWidget
{
    Q_OBJECT

	public:
    	RotationWidget(QWidget *parent = NULL, Qt::WFlags flags = 0);
    	~RotationWidget();


    //[-------------------------------------------------------]
    //[ Public signals                                        ]
    //[-------------------------------------------------------]
	signals:
         void rotationChanged(int deltaX, int deltaY, int deltaZ);
         void rotationReset();


    //[-------------------------------------------------------]
    //[ Protected slots                                       ]
    //[-------------------------------------------------------]
	protected slots:
	    void rotateXMinus();
	    void rotateXPlus();
	    void rotateYMinus();
	    void rotateYPlus();
	    void rotateZMinus();
	    void rotateZPlus();

};


#endif // __FRAMEWORK_OPENGL_ROTATIONWIDGET_H__
