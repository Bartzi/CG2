#ifndef __FRAMEWORK_MODEL_H__
#define __FRAMEWORK_MODEL_H__

#ifdef WIN32
  #define _CRT_SECURE_NO_WARNINGS
#endif // WIN32

#include <string>
#include <vector>

class Model
{
	public:
		struct Vertex   { double x; double y; double z; };
		struct Normal	{ double x; double y; double z; int vertices; };
		struct TexCoord { double u; double v; };
		struct Face     { int vertex0; int texCoord0; int vertex1; int texCoord1; int vertex2; int texCoord2; };

	public:
		Model();
		~Model();
		void load(const std::string &filename);
		void clear();
		void render();

	protected:
		std::vector<Vertex>   m_vertices;
		std::vector<Normal>   m_normals;
		std::vector<TexCoord> m_texCoords;
		std::vector<Face>     m_faces;
};


#endif // __FRAMEWORK_MODEL_H__
