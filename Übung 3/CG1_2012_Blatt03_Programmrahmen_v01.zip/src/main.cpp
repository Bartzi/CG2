#include "MainWindow.h"

//
// Qt
//
#include <QtGui/QApplication>

//[-------------------------------------------------------]
//[ Main function                                         ]
//[-------------------------------------------------------]
int main(int argc, char *argv[])
{
    // Create application
    QApplication app(argc, argv);

    // Create main window
    MainWindow *window = new MainWindow();
    window->resize(600, 480);
    window->show();

    // Run application
    return app.exec();
}
