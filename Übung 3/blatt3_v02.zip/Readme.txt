win32 - the gui way:
- start cmake-gui with batch or manually (but provide GLEW_HOME and GLUT_HOME)
- drag CMakeLists.txt into cmake-gui
- build binaries in extra build directory
- configure and generate for x86 (binaries for x64 are not included)
- open solution with batch
- setup working directory to $(TargetDir) for each configuration you want to start your program in

gcc (inofficial)
- libglew and libglew-dev required (e.g. 1.6) -> use apt-get
- libglut is required but should be available...
- run cmake
- make
- probably a little more :D